#include "slist.h"


int delete_element(slink **head , data_t data)
{
    slink *temp , *temp2; //take a local reference of head
    temp = *head;
    

    if(NULL == (*head))   // check for if list is empty
    {
       return EMPTYLIST;
    }
    
    if(((*head)->link) == NULL)  // check for if list has only one node 
    {
       if(((*head)->data) == data)
       {
          free(temp);
          (*head) = NULL;
          return SUCCESS;
       }
       else
       {
          return NOELEMENT;
       }
    }
    else
    {
       if(((*head)->data) == data)
       {
           temp2 = (*head);
           (*head) = (*head)->link;

           temp2->link = NULL; 
           free(temp2);
       }
       else
       {
           while(temp->link)  // if the list has multiple nodes and iterate till the last node
           {
               if(((temp->link)->data) != data)
               {
                   if(((temp->link)->link) == NULL)
                   {
                       return NOELEMENT;
                   }
                   temp = temp->link;
               }
               else
               {
                   break;
               }
           }
           temp2= temp->link;  // take a local reference to the element node 

           (temp->link) = temp2->link;  // update nodes link free the next node that contains element 
           free(temp2);
       }
       return SUCCESS;
    }
    return FAILURE;
}


