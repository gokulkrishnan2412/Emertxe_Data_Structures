#include "slist.h"


int insert_after(slink **head , data_t a_data , data_t n_data)
{
    slink *temp;          //take a local reference of node
    temp = *head;

    if(NULL == (*head))
    {
        return EMPTYLIST;
    }

    slink *new = malloc(sizeof(slink)); // create a newnode and update newnode data and link

    if(NULL == new)
    {
        return FAILURE;
    }

    new->data = n_data;
    new->link = NULL;
 

    if(((*head)->link) == NULL)  // check if list has only one node
    {
        if(((*head)->data) == a_data)  // if the node is the given element after which we need to add newnode
        {
            ((*head)->link) = new;      //update first + newnode
            return SUCCESS;
        }
        else
        {
            return NOELEMENT;
        }
    }
    else
    {
        while(temp)         // iterate through the list till you find the element after which new data has to be added 
        {
            if((temp->data) != a_data)
            {
                if(temp->link == NULL)
                {
                    return NOELEMENT;
                }
            }
            else
            {
                break;
            }
            temp = temp->link;
        }

        if(temp->link == NULL)   // check for end node
        {
            (temp->link) == new;
            return SUCCESS;
        }
        else
        {
            new->link = temp->link; // update the newnodes link

            temp->link = new;  // update current node  + newnode
            return SUCCESS;
        }
    }
        return FAILURE;
}   



