#include "slist.h"

int insert_at_first(Slink **head, data_t data)
{
	Slink *new = malloc(sizeof(Slink));
	if(NULL == new)
	{
		return Failure;
	}

	// update newnode data and link
	new -> data = data;
	new -> link = NULL;

	// if empty link
	if((*head) == NULL)
	{
		(*head) = new;
		return Success;
	}
	else
	{
		// Establish link between new node and first node
		new -> link = *head;

		// Update head
		(*head) = new;
		return Success;
	}
	return Failure;
}
