/*comments
  Name: Gokula Krishnan
  Date: 23/06/21
*/

#include "slist.h"

int main()
{
	slink *head = NULL;

	int data,a_data,index,result, choice;
	char option;
	do
	{
		printf("Enter the option:\n");
		printf("1. Insert After\n");
		printf("2. Insert Before\n");
		printf("3. Delete element\n");
		printf("4. Insert nthelement\n");
        printf("5. Insert at first\n");

		printf("Choice: ");
		scanf("%d", &choice);

		switch(choice)
		{
			case 1:
				printf("Enter the element after which you want to insert new data: ");
				scanf("%d", &a_data);
                printf("Enter the element to be inserted after the element %d: ", a_data);
                scanf("%d" , &data);
				result = insert_after(&head,a_data,data);
				(result == SUCCESS)? printf("insert_after Success\n") : printf("insert_after Failure\n");
                if(result == NOELEMENT)
                {
                    printf("No such element found\n");
                }
                else if(result == EMPTYLIST)
                {
                    printf("List is empty\n");
                }
                break;
			case 2:
				printf("Enter the element before which you want to insert new data: ");
				scanf("%d", &a_data);
                printf("Enter the element to be inserted before the element %d: ", a_data);
                scanf("%d" , &data);
				result = insert_before(&head,a_data,data);
				(result == SUCCESS)? printf("insert_before Success\n") : printf("insert_before Failure\n");
                if(result == NOELEMENT)
                {
                    printf("No such element found\n");
                }
                else if(result == EMPTYLIST)
                {
                    printf("List is empty\n");
                }
				break;
            case 3:
                printf("Enter the element thats needs to be deleted: ");
                scanf("%d" , &data);
                result = delete_element(&head , data);
				(result == SUCCESS)? printf("Delete_element Success\n") : printf("Delete_element Failure\n");
                if(result == NOELEMENT)
                {
                    printf("No such element found\n");
                }
                else if(result == EMPTYLIST)
                {
                    printf("List is empty\n");
                }                
                break;
            case 4:
                printf("Enter the index value to insert the value[starts from 0]: ");
                scanf("%d" , &index);
                printf("Enter the element to be inserted at index%d: ",index);
                scanf("%d" , &data);

                result = insert_nth(&head , index , data);
				(result == SUCCESS)? printf("insert_nth Success\n") : printf("insert_nth Failure\n");

                if(result == NOELEMENT)
                {
                    printf("Index out of bound\n");
                }
                else if(result == EMPTYLIST)
                {
                    printf("List is empty\n");
                }
                break;
            case 5:
                printf("Enter the element to be inserted at first: ");
                scanf("%d" , &data);
                result = insert_at_first(&head , data);
				(result == SUCCESS)? printf("insert_at_first Success\n") : printf("insert_at_first Failure\n");
                break;                 
            default:
				printf("Invalid entry\n");
				break;
		}
		// Check list for validation
		print_list(head);

		printf("Do you want to continue(y/n): ");
		scanf("\n%c", &option);
	}while(option == 'y' || option == 'Y');
}
