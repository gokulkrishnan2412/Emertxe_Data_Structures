#include<stdio.h>
#include<stdlib.h>

#define SUCCESS 0
#define FAILURE -1
#define EMPTYLIST -2
#define NOELEMENT -3

typedef int data_t;

typedef struct snode
{
	data_t data;
	struct snode *link;
}slink;

/* prints the elements in the list */
void print_list(slink *);

/* Insert a node at after */
int insert_after(slink **head, data_t a_data ,data_t n_data);

/* Insert a node before */
int insert_before(slink **head, data_t b_data ,data_t n_data);

/* Delete a node from the list */
int delete_element(slink **head , data_t data );

/* insert a node at a given index in the list if valid index is given within list */
int insert_nth(slink **head , int index , data_t data);

/*insert node at first */
int insert_at_first(slink **head , data_t data);
