#include "dlist.h"


int delete_element(DLink **head , data_t data)
{
    DLink *temp;   //Take a local refernce of head 
    temp = *head;

    if(NULL == (*head))   // check for list is empty
    {
        return EMPTYLIST;
    }

    if( ((*head) -> next) == NULL)  // check for if list has only one node
    {
        if(((*head) -> data) == data)   // check if the element is the one that needs to be deleted            
        {
            free(temp);      // free the node and head with null
            (*head) = NULL;
            return SUCCESS;
        }
        else
        {
            return NOELEMENT;
        }
    }
    else                                        // if list has multiple nodes
    {
        if( ((*head) -> data) == data)            //if the element is in the head then check for next values
        {
            (*head) = (*head)->next;         // update head to the next value
            ((*head)->prev)->next = NULL;    //unlink the previous node and free
            free((*head)->prev);
            (*head)->prev = NULL;       //update the previous of head to null
        }
        else
        {
            while(temp)
            {
                if((temp->data) != data)  // check if node is given element 
                {
                    if(temp->next == NULL) // if no element is found at all the return 
                    {
                        return NOELEMENT;
                    }
                }
                else
                {
                    break;         //if element is present break
                }
                temp = temp->next;
            }
        }

        if(temp->next == NULL)    // check for end node
        {
            (temp->prev)->next = NULL;    //unlink the node
            free(temp);
        }
        else
        {
            (temp->prev)->next = temp->next;
            (temp->next)->prev = temp->prev;

            temp->prev = NULL;
            temp->next = NULL;
            free(temp);
        }
       return SUCCESS;
    }
   return FAILURE;      
}             
