#include "dlist.h"


int insert_after(DLink **head , data_t a_data , data_t n_data)
{
    DLink *temp;             // take a local reference of head
    temp = *head;

    if(NULL == (*head))
    {
        return EMPTYLIST;
    }

    DLink *new = malloc(sizeof(DLink));   // create a newnode and update newnode data and link
    new->data = n_data;
    new->next = NULL;
    new->prev = NULL;

    if( ((*head)->next) == NULL)
    {
        if(((*head)->data) == a_data) // if the node is the given element after which we need to add newnode
        {
            ((*head)->next) = new;
             (new->prev) = *head;
             return SUCCESS;
        }
        else
        {
            return NOELEMENT;
        }
    }
    else
    {
        while(temp)
        {
            if((temp->data) != a_data)
            {
                if(temp->next == NULL)   // if no element is found at all then return 
                {
                    return NOELEMENT;
                }
            }
            else
            {
                break;         // if element is present break
            }
            temp = temp->next;
        }

        if(temp->next == NULL)       // check for end node
        {
            (temp->next) = new;   // update last + newnode
            new->prev = temp;    // update prev of newnode

            return SUCCESS;
        }
        else
        {
            new->next = temp->next; // update the newnodes next
            new->prev = temp;      // update the newnodes prev
            temp->next = new;       // update current node + newnode

            return SUCCESS;
        }
    }
    return FAILURE;
}



             
