#include "dlist.h"


int insert_at_first(DLink **head , data_t data)
{
    DLink *new = malloc(sizeof(DLink));

    DLink *temp;
    temp = (*head);

    if(NULL == new)
    {
        return FAILURE;
    }

    new->data = data;
    new->prev = NULL;
    new->next = NULL;

    if(NULL == (*head))
    {
        (*head) = new;
        return SUCCESS;
    }

    temp->prev = new;
    new->next = temp;

    (*head) = new;

    return SUCCESS;
}
