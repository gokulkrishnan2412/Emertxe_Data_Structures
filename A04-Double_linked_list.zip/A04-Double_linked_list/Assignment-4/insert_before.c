#include "dlist.h"

int insert_before(DLink **head , data_t b_data , data_t n_data)
{
    DLink *temp;
    temp = *head;

    if(NULL == (*head))
    {
        return EMPTYLIST;
    }

    DLink *new = malloc(sizeof(DLink));
    new->data = n_data;
    new->next = NULL;
    new->prev = NULL;

    if(((*head)->next) == NULL)
    {
        if(((*head)->data) == b_data)
        {
            new->next = *head;
            (*head)->prev =new;

            (*head) = new;
            return SUCCESS;
        }
        else
        {
            return NOELEMENT;
        }
    }
    else
    {
        if(((*head)->data) == b_data)
        {
            new->next = *head;
            (*head)->prev = new;

            (*head) = new;
            return SUCCESS;
        }
        else
        {
            while(temp)
            {
                if(temp->data != b_data)
                {
                    if(temp->next == NULL)
                    {
                        return NOELEMENT;
                    }
                }
                else
                {
                    break;
                }
                temp = temp->next;

            }

            new->next = temp;
            new->prev = temp->prev;

            (temp->prev)->next = new;
            temp->prev = new;
            return SUCCESS;
        }
    }
    return FAILURE;
}

