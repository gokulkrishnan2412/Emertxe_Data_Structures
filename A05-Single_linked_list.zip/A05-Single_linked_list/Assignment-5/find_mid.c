#include "slist.h"

int find_mid(slink *head)
{
    slink *temp = head;

    int i , index = 0;

    if(NULL == (temp))
    {
        return EMPTYLIST;
    }
    else
    {

        while(temp)
        {
            index++;
            temp = temp->link;

        }


        if(index == 1)
        {
            return head->data;
        }
        else
        {
            index = index/2;
            return getNth(head,index);
        }

    }
    return FAILURE;
}

