#include "slist.h"

int getNth(slink *head , int index)
{

    slink *temp = head;        //take a local reference to traverse through the link

    int i;

    if(NULL == temp)     // check if list is empty
    {
        return EMPTYLIST;
    }
    else
    {
        for(i = 0 ; i < index ; i++ ) // iterate through the link till the index value
        {
            temp = temp->link;  
            if(temp == NULL)
            {
                return NOELEMENT;
            }
        }

        return temp->data;   // temp will be at the index value so return the data if the index is within the list length
    }
    return FAILURE;
}
