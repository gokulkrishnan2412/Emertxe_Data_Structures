#include "slist.h"

int insert_at_first(slink **head, data_t data)
{
	slink *new = malloc(sizeof(slink));
	if(NULL == new)
	{
		return FAILURE;
	}

	// update newnode data and link
	new -> data = data;
	new -> link = NULL;

	// if empty link
	if((*head) == NULL)
	{
		(*head) = new;
		return SUCCESS;
	}
	else
	{
		// Establish link between new node and first node
		new -> link = *head;

		// Update head
		(*head) = new;
		return SUCCESS;
	}
	return FAILURE;
}
