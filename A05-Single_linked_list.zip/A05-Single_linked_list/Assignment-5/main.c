/*Comments
  Name: Gokula Krishnan
  Date: 30/06/21
*/


#include "slist.h"

int main()
{
	slink *head = NULL;

	int data,a_data,index,result, choice;
	char option;
	do
	{
		printf("Enter the option:\n");
		printf("1. find_mid\n");
		printf("2. get_nth_last\n");
        printf("3. Insert at first\n");

		printf("Choice: ");
		scanf("%d", &choice);

		switch(choice)
		{
			case 1:
				result = find_mid(head);
                if(result == EMPTYLIST)
                {
                    printf("List is empty\n");
                    break;
                }
				(result == FAILURE)? printf("find_mid Failure\n") : printf("mid value is: %d\n", result);
                break;
            case 2:
                printf("Enter the index value to insert the value[starts from 0]: ");
                scanf("%d" , &index);           
                result = getNth(head , index);

                if(result == NOELEMENT)
                {
                    printf("No such element found\n");
                }
                else if(result == EMPTYLIST)
                {
                    printf("List is empty\n");
                }                
				(result == FAILURE)? printf("getNth Failure\n") : printf("Nth value is: %d\n", result);
                break;   
            case 3:
                 printf("Enter the element to be inserted at first: ");
                 scanf("%d" , &data);

                 result = insert_at_first(&head , data);
                 (result == SUCCESS)?printf("insert_at_first Success\n") : printf("insert_at_first Failure\n");
                 break;
            default:
                 printf("Invalid choice\n");
                 break;
        }

        print_list(head);

        printf("Do you want to continue(y/Y): ");
        scanf("\n%c" , &option);
    }while( option == 'y' || option == 'Y');

    return 0;
}
