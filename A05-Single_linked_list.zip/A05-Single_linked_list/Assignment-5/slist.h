#include<stdio.h>
#include<stdlib.h>

#define SUCCESS 0
#define FAILURE -1
#define EMPTYLIST -2
#define NOELEMENT -3

typedef int data_t;

typedef struct snode
{
	data_t data;
	struct snode *link;
}slink;

/* prints the elements in the list */
void print_list(slink *);

/* find the mid node index  of the list */
int find_mid(slink *);

/* find a node at given index in the list if present */
int getNth(slink *head , int index);

/*insert node at first */
int insert_at_first(slink **head , data_t data);
