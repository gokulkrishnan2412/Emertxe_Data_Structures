#include <stdio.h>
#include <stdlib.h>

#define SUCCESS 0
#define FAILURE -1
#define EMPTYLIST -2
#define NOELEMENT -3

typedef int data_t;
typedef struct snode
{
	data_t data;
	struct snode *link;
}SLink;


/* insert a node in the list in sorted manner
 */
int sorted_insert(SLink **head, data_t data);


