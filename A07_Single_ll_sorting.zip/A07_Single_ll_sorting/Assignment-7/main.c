/*Comments
Name : Gokula Krishnan
Date : 30/06/2021
*/

#include "slist.h"

int main()
{
	SLink *head = NULL;

	int data, result, index;
	int choice;
	char option;
	
	do
	{
	        printf("Enter the option:\n");
         	printf("1. Insert At Last\n");	
        	printf("2. sort list\n");

        	printf("Choice: ");
        	scanf("%d", &choice);

        	switch(choice)
        	{
        		case 1:
        			printf("Enter the element to be inserted at last: ");
        			scanf("%d", &data);
        			result = insert_at_last(&head, data);
        			(result == SUCCESS)? printf("insert_at_last SUCCESS\n"): printf("insert_at_last FAILURE\n") ;
        			break;
        		case 2:
        			result = insert_sort(&head);
        			(result == SUCCESS)? printf("insert_sort SUCCESS\n"): printf("insert_sort FAILURE\n") ;
        			if (result == EMPTYLIST)
        			{
        				printf("List is empty\n");
        				break;
        			}
        			break;
        		default:
        			printf("Invalid entry.\n");
        			break;
        	}
        
        	//check the list for validating
        	print_list(head);
        	
        	/* check for continue */
                printf("Do you want to Continue (y/n): ");
                scanf("\n%c", &option);
                
                if ( option == 'y' )
                {
                    continue;
                } else
                {
                    break;
                }
                
         } while (1);
		
         return 0;
}
