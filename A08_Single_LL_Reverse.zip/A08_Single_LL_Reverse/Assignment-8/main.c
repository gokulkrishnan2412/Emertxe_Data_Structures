/*comments
Name: Gokula Krishnan
Date: 05/07/21
 */

#include<stdio.h>
#include "slist.h"

int main()
{
	slink *head = NULL;

	int data,a_data,index,result, choice;
	char option;
	do
	{
		printf("Enter the option:\n");
        printf("1. Insert_at_first\n");
        printf("2. Insert_at_last\n");


		printf("Enter your choice: ");
		scanf("%d", &choice);

		switch(choice)
		{

            case 1:
                printf("Enter the element to be inserted at last: ");
                scanf("%d" , &data);

                result = insert_at_first(&head , data);
				(result == SUCCESS)? printf("insert_at_first Success\n") : printf("insert_at_first Failure\n");
                break;
            case 2:
                result = insert_at_last(&head, data);
				(result == SUCCESS)? printf("insert_at_last Success\n") : printf("insert_at_last Failure\n");
                if(result == EMPTYLIST)
                {
                    printf("List is empty\n");
                }
                break;                 
            default:
				printf("Invalid entry\n");
				break;
		}
		// Check list for validation
		print_list(head);

		printf("Do you want to continue(y/n): ");
		scanf("\n%c", &option);
	}while(option == 'y' || option == 'Y');
}
