#include<stdio.h>
#include<stdlib.h>

#define SUCCESS 0
#define FAILURE -1
#define EMPTYLIST -2
#define NOELEMENT -3

typedef int data_t;

typedef struct snode
{
	data_t data;
	struct snode *link;
}slink;

void print_list(slink *);

int insert_at_first(slink **head, data_t data);

int reverse(slink **head, data_t data);

int insert_at_last(slink **head , data_t data);
