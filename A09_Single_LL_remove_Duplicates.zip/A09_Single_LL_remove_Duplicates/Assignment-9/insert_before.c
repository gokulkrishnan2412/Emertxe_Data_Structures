#include "slist.h"


int insert_before(slink **head , data_t b_data , data_t n_data)
{
    slink *temp;          //take a local reference of node
    temp = *head;

    if(NULL == (*head))
    {
        return EMPTYLIST;
    }

    slink *new = malloc(sizeof(slink)); // create a newnode and update newnode data and link

    if(NULL == new)
    {
        return FAILURE;
    }

    new->data = n_data;
    new->link = NULL;
 

    if(((*head)->link) == NULL)  // check if list has only one node
    {
        if(((*head)->data) == b_data)  // if the node is the given element after which we need to add newnode
        {
            new->link = *head;      //establish a link between newnode and first node
            (*head) = new;
            return SUCCESS;
        }
        else
        {
            return NOELEMENT;
        }
    }
    else
    {
        if(((*head)->data) == b_data)   // if element is in the head
        {
            new->link = *head;
            (*head) = new;
            return SUCCESS;
        }
        else                             // if the element is in the middle or end
        {
            while((temp->link))  // if the list has multiple nodes and iterate till last 
            {
                if(((temp->link)->data) != b_data)
                {
                    if(((temp->link)->link) == NULL)
                    {
                        return NOELEMENT;
                    }
                    temp = temp->link;
                }
                else
                {
                    break;
                }
            }
            new->link = temp->link;
            (temp->link) = new;
            return SUCCESS;
        }
    }
    return FAILURE;
}
