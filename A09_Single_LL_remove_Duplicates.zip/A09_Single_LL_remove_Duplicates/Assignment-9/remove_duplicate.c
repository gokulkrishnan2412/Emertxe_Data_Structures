#include "slist.h"


int remove_duplicate(slink **head)
{
    slink *next , *result; //to keep track of next next link for duplicate cases

    if(NULL == (*head))  // check if list is empty
    {
       return EMPTYLIST;
       
    }
    
    insert_sort(head); // sort the given list

    slink *temp;
    temp = *head;

    if((*head)->link == NULL)
    {
        return SUCCESS;
    }

    {
    while(temp->link)
    {
        if(temp->data != (temp->link)->data)
        {
            if(((temp->link)->link) == NULL)
            {
                return SUCCESS;
            }

            temp = temp->link;

        }
        else
        {
            next = temp->link;
            delete_element(head,temp->data);
            temp = next;
        }
    }
     return SUCCESS;
    }
    return FAILURE;
}



     
