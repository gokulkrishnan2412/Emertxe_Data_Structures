#include<stdio.h>
#include<stdlib.h>

#define SUCCESS 0
#define FAILURE -1
#define EMPTYLIST -2
#define NOELEMENT -3

typedef int data_t;

typedef struct snode
{
	data_t data;
	struct snode *link;
}slink;

void print_list(slink *);

int insert_before(slink **head, data_t b_data ,data_t n_data);

int delete_element(slink **head , data_t data);

int sorted_insert(slink **head , data_t data);

int insert_sort(slink **head);

int remove_duplicate(slink **head);

int insert_at_last(slink **head , data_t data);
