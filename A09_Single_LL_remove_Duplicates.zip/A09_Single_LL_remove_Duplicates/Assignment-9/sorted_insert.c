#include "slist.h"


int sorted_insert(slink **head , data_t data)
{
    slink *temp;   // take a local reference of head 
    temp = *head;

    slink *new = malloc(sizeof(slink));

    if(NULL == new)
    {
        return FAILURE;
    }

    new->data= data;   // update newnode data and link
    new->link = NULL;

    if(NULL == (*head))  // chec if list is empty
    {
        (*head) = new;
        return SUCCESS;
    }

    if((*head)->link == NULL)   // check if a single node 
    {
        if( ((*head)->data) >= data)
        {
            new->link = *head;
            (*head) = new;
            return SUCCESS;
        }
        else
        {
            (*head)->link = new;
            return SUCCESS;
        }
    }
    else              // check if multi node
    { 
        while(temp) 
        {

            if((temp->data) >= data)      // if list data is greater than the given data , then add before this node 
            {
                insert_before(head , temp->data , data);
                return SUCCESS;
            }
            else if( (temp->data) < data)  // if list data is less than given data that needs to be inserted 
            {

                if((temp->link) == NULL)  // if no element is found at all the return 
                {
                    temp->link = new;  // if the last node is reached , then add the new node at end 
                    return SUCCESS;
                }
            }
            temp = temp->link;  // update the link
        }
    }
    return FAILURE;
}
