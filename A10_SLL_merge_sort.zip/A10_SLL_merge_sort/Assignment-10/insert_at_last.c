#include "slist.h"


int insert_at_last(slink **head , data_t data)
{
    slink *temp;         // take local refernce of head
    temp = *head;

    slink *new = malloc(sizeof(slink));    

    if(NULL == new)
    {
        return FAILURE;
    }

    new->data = data;    //update the data and link
    new->link = NULL;

    if(NULL == (*head))  // if list is empty
    {
        (*head) = new;
        return SUCCESS;
    }
    else
    {
        while(temp->link)  // iterate till the last
        {
            temp = temp->link;
        }
        (temp->link) = new; // establish link between last + new node and update 
    }
    return SUCCESS;
}
