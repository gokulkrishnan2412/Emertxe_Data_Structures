/*Comments
Name:Gokula Krishnan
Date: 7/7/2021
*/

#include "slist.h"

int main()
{
	slink *head = NULL;
	slink *ahead = NULL;
	slink *bhead = NULL;

	int data, a_data, result, index;
	int choice;
	char option;
	int aListElement, bListElement, i;
	
do
{
			ahead = NULL; 
			 
			printf("Enter the number of elements in list a: ");
			scanf("%d", &aListElement);
			printf("Enter the elements:\n");
			for(i = 0; i < aListElement;i++)
			{
				printf("%d: ", i);
				scanf("%d", &data);
				result = insert_at_last(&ahead, data);
				//(result == SUCCESS)? printf("insert in alist SUCCESS\n"): printf("insert in alist FAILURE\n") ;
			}
	
			bhead = NULL;
			printf("Enter the number of elements in list b: ");
			scanf("%d", &bListElement);
			printf("Enter the elements:\n");
			for(i = 0; i < bListElement;i++)
			{
				printf("%d: ", i);
				scanf("%d", &data);
				result = insert_at_last(&bhead, data);
				//(result == SUCCESS)? printf("insert in blist SUCCESS\n"): printf("insert in blist FAILURE\n") ;
			}

			head = merge_sortedlinks(ahead, bhead);
						
			break;

	//check the list for validating
	print_list(head);
	
	/* check for continue */
        printf("Do you want to continue (y/n): ");
        scanf("\n%c", &option);

} while(option == 'y');
       
		
    return 0;
}
