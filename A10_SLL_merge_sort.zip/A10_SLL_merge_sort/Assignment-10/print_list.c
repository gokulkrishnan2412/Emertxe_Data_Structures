#include "slist.h"

void print_list(slink *head)
{
	/* Taking a temp pointer to traverse through the link */
	slink *temp = head;

	while(temp)
	{
		printf("%d ", temp -> data);
		temp = temp -> link; 
		printf("Successful");
	}
	printf("\n");
}
