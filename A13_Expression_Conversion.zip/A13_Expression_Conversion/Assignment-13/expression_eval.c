#include "stack.h"


int expressionEvaluation(int valueA , int valueB , char symbol)
{
    int a,b;

    if( valueA >= '0' && valueA <= '9' )
    {
        a = ( valueA - '0');
    }
    else
    {
        a = valueA;
    }
    if( valueB >= '0' && valueB <= '9' )
    {
        b = ( valueB - '0');
    }
    else
    {
        b = valueB;
    }

    switch(symbol)
    {
        case '+':
            return (a + b);
            break;
        case '-':
            return (a - b);
            break;
        case '*':
            return (a * b);
            break;
        case '/':
            return (a / b);
            break;
        case '%':
            return (a % b);
            break;
        default:
            break;
    }
}
