/*Comments
Name: Gokula Krishnan
Date: 1-7-2021*/

#include "stack.h"


int infixTopostfix(char infixexp[STACKSIZE] , char postfixexp[STACKSIZE])
{
    int infixexplen , i, j= 0;
    char data;

    Stack operatorstackArray;    // initialization of stack
    operatorstackArray.top = -1;

    infixexplen = strlen(infixexp);  // get the length of infixexp

    for( i = 0 ; i < infixexplen ; i++ ) //push the values in to stack and pop to get postfix exp while traversing 
    {
       if(infixexp[i] == '(')   // if the operator is '('  then push this in to stack 
       {
          push(&operatorstackArray , infixexp[i]);
       }
       else if( ! isOperator(infixexp[i]))
       {
          postfixexp[j] = infixexp[i];
          j++;
       }
       else if(infixexp[i] == ')')
       {
           while(peek(operatorstackArray) != '(')  // if there are no other innser brackets
           {
               pop(&operatorstackArray , &data);  // get the operator from the top and save it on to postfix and increment the index
               postfixexp[j] = data;
               j++;
           }

           pop(&operatorstackArray , &data); // pop the operator out of the stack , as it copied 
       }
       else
       {
           // pop out the operators and save in prefix till it become less than 
           while( checkPrecedence(peek(operatorstackArray)) >= checkPrecedence(infixexp[i]) )
           {
               pop(&operatorstackArray , &data);
               postfixexp[j] = data;
               j++;
           }

           push(&operatorstackArray , infixexp[i]);//once the stack is cleared of that , push the new operator 
       }

    }
   //after operator check , till stack becomes empty , pop the values and save in postfixexp and increment the index
    while(operatorstackArray.top != -1 )
    {
        pop(&operatorstackArray , &data);
        postfixexp[j] = data;
        j++;
    }

    postfixexp[j] = '\0'; // make postfixexp string

    return SUCCESS;
}
