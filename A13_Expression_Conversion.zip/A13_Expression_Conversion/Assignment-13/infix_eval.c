#include "stack.h"


int infixEval(char infixexp[STACKSIZE])
{
    char postfixexp[STACKSIZE];

    //change this infixexp to prefixexp
    infixTopostfix(infixexp , postfixexp);

    //evaluate prefix expression and return
    return postfixEval(postfixexp);
} 
