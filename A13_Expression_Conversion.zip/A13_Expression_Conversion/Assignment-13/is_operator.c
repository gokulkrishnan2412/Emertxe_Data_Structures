#include "stack.h"

int isOperator(char symbol)
{
    switch(symbol)
    {
        case '*':
        case '+':
        case '-':
        case '{':
        case '}':
        case '(':
        case ')':
        case '/':
        case '%':
            return 1;
            break;
        default:
            return 0;

    }
}

