/*Comments

Name: Gokula Krishnan
Date: 1/07/21
Assignment-13*/

#include "stack.h"


int main()
{
    Stack stackArray;          // initialize the stack
    stackArray.top = -1;

    char infixexp[STACKSIZE];  //to hold infix and postfix exp
    char postfixexp[STACKSIZE];

    int infixlen , i;
    int choice , result;
    char option;

    do
    {
        printf("Enter the option:\n");
        printf("1. infix to postfix\n");
        printf("2. infix Evaluation\n"); 
        printf("3. postfix evaluation\n");


        printf("choice: ");
        scanf("%d" , &choice);

        switch(choice)
        {
            case 1:
                printf("Enter the infix expression: ");
                scanf("%s" , infixexp);

                result = infixTopostfix(infixexp , postfixexp);
                (result == SUCCESS)?printf("infixTopostfix SUCCESS\n"):printf("infixTopostfix FAILURE\n");
                printf("%s\n" , postfixexp);
                break;
            case 2:
                printf("Enter the infix expression: ");
                scanf("%s" , infixexp);

                result = infixEval(infixexp);
                printf("in fix evaluation: %d \n" , result);
                break;
            case 3:
                result = postfixEval(postfixexp);
                printf("post fix evaluation: %d \n", result);
                break;
            default:
                printf("Invalid choice\n");
                break;
        }

        peep(stackArray);

        printf("Do you want to continue(y/Y): ");
        scanf("\n%c" , &option);
    }while( option == 'y' || option == 'Y');

    return 0;
}
