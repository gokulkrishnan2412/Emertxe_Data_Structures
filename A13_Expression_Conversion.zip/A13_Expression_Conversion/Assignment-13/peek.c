#include "stack.h"

int peek(Stack S)
{
    if(S.top == -1 )  // check if stack is empty 
    {
        return STACKEMPTY;
    }

    return S.Sarray[S.top]; // else return the element present at the top most in the stack 
}

