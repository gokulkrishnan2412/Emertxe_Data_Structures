#include "stack.h"

int peep(Stack S)
{
    int temp = S.top;   // take a local reference to traverse along the stack

    do
    {
        if((temp) == -1)   //check if stack is empty 
        {  
           return STACKEMPTY;
        }

        printf("%d " , S.Sarray[temp]);  //print the values present at that place 

        (temp)--;                 // decrement the temp by one and repeat till the elements are printed 
    }while(temp != -1);

    printf("\n");
    return SUCCESS;
}
