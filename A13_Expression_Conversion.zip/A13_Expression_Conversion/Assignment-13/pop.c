#include "stack.h"

int pop(Stack *S , data_t *data)
{

    if((S->top) == -1)  // check if the stack is empty
    {
        return STACKEMPTY;
    }

    (*data) = S->Sarray[S->top];   // else retrive the data from the stack at top and save in data

    (S->top)--;       // decrement the top by 1

    return SUCCESS;
}
