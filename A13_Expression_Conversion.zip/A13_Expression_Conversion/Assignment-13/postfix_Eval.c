#include "stack.h"

int postfixEval(char postfixexp[STACKSIZE]) 
{
    int postfixexplen , i , j=0;
    char data;

    char int_valueA , int_valueB , int_result;

    Stack evaluationStackArray;         // initialization of stack
    evaluationStackArray.top = -1;

    postfixexplen = strlen(postfixexp);  // get the length of postfixexp

    for( i = 0 ; i < postfixexplen ; i++ )
    {
        if(! isOperator(postfixexp[i]) ) // if its  not any operator , push postfixexp into evaluation stack array
        {
            push(&evaluationStackArray , postfixexp[i]);
        }

        if(isOperator(postfixexp[i]) )
        {
            pop(&evaluationStackArray , &data); // pop the stack and call the value B
            int_valueB = data;

            pop(&evaluationStackArray , &data); // pop the stack and call the valuie A
            int_valueA = data;

            int_result = expressionEvaluation(int_valueA , int_valueB , postfixexp[i]); // evaluate A and B  using opertor just found

            int_result += '0';  // chnage this int to ascii equivalent 


            push(&evaluationStackArray , int_result); // push the resulting value on to the stack 

        }

    }

   pop(&evaluationStackArray , &data);  //pop the stack and this will be the final value 

   return ( data - '0' );
}

                

