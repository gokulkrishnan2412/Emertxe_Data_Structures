#include "stack.h"


int push(Stack *S , data_t data)
{

    if((S-> top) == (STACKSIZE - 1 )) // check if stack is full 
    {
        return STACKFULL;
    }

    (S->top)++;              // else increment the top by 1

    S->Sarray[S->top] = data;  // save the data at the place in the array  

    return SUCCESS;
}
