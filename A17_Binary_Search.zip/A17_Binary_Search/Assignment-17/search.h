#include <stdio.h>
#include <stdlib.h>

#define SUCCESS 0
#define FAILURE -1
#define ARRAYSIZE 25
#define NOELEMENT -2

int binarySearchIterative(int arr[], int left, int right, int data);

int binarySearchRecursive(int arr[], int left, int right, int data);
