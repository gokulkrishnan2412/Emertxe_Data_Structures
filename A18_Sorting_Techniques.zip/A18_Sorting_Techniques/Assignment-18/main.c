/*Comments
Name: Gokula Krishnan
Date: 7/7/2021 */

#include "sort.h"

int main()
{
	int elementArray[ARRAYSIZE];

	int totalElements, result;
	int choice, i = 0;
	char option;
	
	do
	{
	
	printf("Enter the option:\n");
	printf("1. create an array\n");		
	printf("2. bubbleSort\n");	
	printf("3. insertionSort\n");	
	printf("4. selectionSort\n");	
	printf("5. display array\n");
	
	printf("Enter your choice: ");
	scanf("%d", &choice);

	switch(choice)
	{
		case 1:
			printf("Enter the total number of element to be inserted in an array: ");
			scanf("%d", &totalElements);
		
			for(i = 0; i < totalElements; i++)
			{
				printf("%d: ", i);
				scanf("%d", &elementArray[i]);
			}	
		

			break;
		
		case 2: 
			result = bubbleSort(elementArray, totalElements);
			(result == SUCCESS)? printf("bubbleSort SUCCESS\n"): printf("bubbleSort FAILURE\n") ;
			
			//check the list for validating
			print_array(elementArray, totalElements);
	
			break;

		case 3: 
			result = insertionSort(elementArray, totalElements);
			(result == SUCCESS)? printf("insertionSort SUCCESS\n"): printf("insertionSort FAILURE\n") ;
			
			//check the list for validating
			print_array(elementArray, totalElements);
	
			break;
		case 4: 
			result = selectionSort(elementArray, totalElements);
			(result == SUCCESS)? printf("selectionSort SUCCESS\n"): printf("selectionSort FAILURE\n") ;
			
			//check the list for validating
			print_array(elementArray, totalElements);
	
			break;

		case 5: 
			print_array(elementArray, totalElements);
			break;
		default:
			printf("Invalid entry.\n");
			break;
	}

	/* check for continue */
        printf("Do you want to continue (y/n): ");
        scanf("\n%c", &option);
        
        if ( option == 'y' )
        {
            continue;
        } else
        {
            break;
        }
        
    } while (1);
		
    return 0;
}
