/* Comments:
Name: Gokula Krishnan
Date: 11/7/2021 */

#include "sort.h"

int main()
{
	int elementArray[ARRAYSIZE];

	int totalElements, result;
	int choice, i = 0;
	char option;
	
	do
	{
	
	printf("Enter the option:\n");
	printf("1. Create an array\n");	
	printf("2. MergeSort\n");
	
	printf("Enter your choice: ");
	scanf("%d", &choice);

	switch(choice)
	{
		case 1:
			printf("Enter the total number of element to be inserted in an array: ");
			scanf("%d", &totalElements);
		
			for(i = 0; i < totalElements; i++)
			{
				printf("%d: ", i);
				scanf("%d", &elementArray[i]);
			}	
		

			break;
		case 2: 
			result = mergeSort(elementArray, totalElements);
			//(result == SUCCESS)? printf("mergeSort SUCCESS\n"): printf("mergeSort FAILURE\n") ;
			
			//check the list for validating
			print_array(elementArray, totalElements);
	
			break;
		
		default:
			printf("Invalid entry.\n");
			break;
	}

	/* check for continue */
        printf("Do you want to continue (y/n): ");
        scanf("\n%c", &option);
        
        if ( option == 'y' )
        {
            continue;
        } else
        {
            break;
        }
        
    } while (1);
		
    return 0;
}

