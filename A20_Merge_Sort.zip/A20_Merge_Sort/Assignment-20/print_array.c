#include "sort.h"


void print_array(int array[], int n)
{
	int i;

	for(i = 0; i < n; i++)
	{
		printf("%d ", array[i]);
	}
	printf("\n");
}

