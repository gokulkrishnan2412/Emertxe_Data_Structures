#include <stdio.h>
#include <stdlib.h>

#define SUCCESS 0
#define FAILURE -1
#define ARRAYSIZE 25
#define NOELEMENT -2



void swap(int *a, int *b);
void print_array(int array[], int n);
void merge(int *array, int narray, int *left, int nleft, int *right, int nright);
int mergeSort(int array[], int narray);
