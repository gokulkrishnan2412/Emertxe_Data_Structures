/*Comments:
Name:Gokula Krishnan
Date:11/7/2021 */

#include "tree.h"

int main()
{
	int result, data;
	int choice, i = 0;
	char option;
	TreeLink * root = NULL;

	do
	{
	
	printf("Enter the option:\n");
	printf("1. Create BST\n");	
	printf("2. search data in BST\n");
	printf("3. Find minimum most data in BST\n");
	printf("4. Find maximum most data in BST\n");
	printf("Enter your choice: ");
	scanf("%d", &choice);

	switch(choice)
	{
		case 1:
			printf("Enter the element to be inserted with first node as root: ");
			scanf("%d", &data);
			result = create_BST(&root, data);
			(result == SUCCESS)? printf("create_BST SUCCESS\n"): printf("create_BST FAILURE\n") ;
			if (result == DUPLICATE)
    			{
      			  	printf("Duplicate found\n");
    			}
				
			break;

		case 2:
			printf("Enter the element to be searched: ");
			scanf("%d", &data);
			result = search_BST(root, data);
			(result == SUCCESS)? printf("search_BST SUCCESS.\nKey found."): printf("search_BST FAILURE\n") ;
			if (result == NOELEMENT)
    			{
      			  	printf("NO ELEMENT found\n");
    			}
				
			break;
		case 3: 
			result = findMin_BST(root);
			if (result == NOELEMENT)
    			{
      			  	printf("NO ELEMENT found\n");
				break;
    			}
			printf("Minimum most Node is: %d\n", result);	
			break;
		case 4: 
			result = findMax_BST(root);
			if (result == NOELEMENT)
    			{
      			  	printf("NO ELEMENT found\n");
				break;
    			}
			printf("Maximum most Node is: %d\n", result);	
			break;	
		default:
			printf("Invalid entry.\n");
			break;
	}

	/* check for continue */
        printf("\nDo you want to continue (y/n): ");
        scanf("\n%c", &option);
        
        if ( option == 'y' )
        {
            continue;
        } else
        {
            break;
        }
        
    } while (1);
		
    return 0;
}
