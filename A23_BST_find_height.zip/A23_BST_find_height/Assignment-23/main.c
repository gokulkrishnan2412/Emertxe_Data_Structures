/*Comments: 
Name: Gokula Krishnan
Date: 11/7/2021 */


#include "tree.h"

int main()
{
	int result, data;
	int choice, i = 0;
	char option;
	TreeLink * root = NULL;

	do
	{
	
	printf("Enter the option:\n");
	printf("1. Create BST\n");	
	printf("2. Find the Tree height\n");
	printf("3. Find the total number of nodes in a tree\n");	

	printf("Enter your choice: ");
	scanf("%d", &choice);

	switch(choice)
	{
		case 1:
			printf("Enter the element to be inserted with first node as root: ");
			scanf("%d", &data);
			result = create_BST(&root, data);
			(result == SUCCESS)? printf("create_BST SUCCESS\n"): printf("create_BST FAILURE\n") ;
			if (result == DUPLICATE)
    			{
      			  	printf("Duplicate found\n");
    			}
				
			break;
	
		case 2: 
			printf("Tree height is: %d\n", getTreeHeight(root));		
			break;
		case 3: 
			printf("Nodes are: %d\n", getTotalNodes(root));	
			break;
		
		default:
			printf("Invalid entry.\n");
			break;
	}

	/* check for continue */
        printf("Do you want to continue (y/n): ");
        scanf("\n%c", &option);
        
        if ( option == 'y' )
        {
            continue;
        } else
        {
            break;
        }
        
    } while (1);
		
    return 0;
}
